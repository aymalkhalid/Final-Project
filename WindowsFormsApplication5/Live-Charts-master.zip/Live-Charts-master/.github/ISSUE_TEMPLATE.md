Instructions: replace text surrounded by '*' with your case, please delete this line.

#### How to reproduce?

*Explain how we can get this issue, if you created a repo with the issue, please add the link, blank if you are submitting a suggestion or improvement*

#### Extra notes

*Explain what you expect, feedback, images or anything you consider necessary*

#### I am using

<table>
<tr>
    <td>Live-Charts version</td>
    <td>*your Live-Charts version here*</td>
</tr>
<tr>
    <td>.Net Version</td>
    <td>*your .net version here*</td>
</tr>
<tr>
    <td>Windows</td>
    <td>*your windows version here*</td>
</tr>
</table>
