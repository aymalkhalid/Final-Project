namespace LiveCharts.Definitions.Charts
{
    /// <summary>
    /// 
    /// </summary>
    public interface IWindowAxisView : IAxisView
    {
        void SetSelectedWindow(IAxisWindow window);
    }
}