namespace LiveChartsCore
{
    public interface IBezierData
    {
        BezierData Data { get; set; }
    }
}