namespace LiveCharts
{
    /// <summary>
    /// 
    /// </summary>
    public class DateSeparatorElementCore : SeparatorElementCore
    {
        /// <summary>
        /// Gets or sets a value indicating whether this separator is a header separator
        /// </summary>
        public bool IsHeader { get; set; }
    }
}