﻿using System;

namespace Wpf.CartesianChart.ConstantChanges
{
    public class MeasureModel
    {
        public DateTime DateTime { get; set; }
        public double Value { get; set; }
    }
}
