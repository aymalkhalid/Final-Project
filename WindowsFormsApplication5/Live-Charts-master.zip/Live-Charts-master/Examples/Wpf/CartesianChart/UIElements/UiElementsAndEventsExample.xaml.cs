﻿using System.Windows.Controls;

namespace Wpf.CartesianChart.UIElements
{
    public partial class UiElementsAndEventsExample : UserControl
    {
        public UiElementsAndEventsExample()
        {
            InitializeComponent();
        }
    }
}
