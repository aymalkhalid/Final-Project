﻿using System.Windows.Controls;

namespace Wpf.CartesianChart.Funnel_Chart
{
    /// <summary>
    /// Interaction logic for FunnelExample.xaml
    /// </summary>
    public partial class FunnelExample : UserControl
    {
        public FunnelExample()
        {
            InitializeComponent();
        }
    }
}
