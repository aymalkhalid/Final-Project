﻿namespace Winforms.Gauge._360
{
    partial class Gauge360Example
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.solidGauge1 = new LiveCharts.WinForms.SolidGauge();
            this.solidGauge2 = new LiveCharts.WinForms.SolidGauge();
            this.solidGauge3 = new LiveCharts.WinForms.SolidGauge();
            this.solidGauge4 = new LiveCharts.WinForms.SolidGauge();
            this.solidGauge5 = new LiveCharts.WinForms.SolidGauge();
            this.solidGauge6 = new LiveCharts.WinForms.SolidGauge();
            this.SuspendLayout();
            // 
            // solidGauge1
            // 
            this.solidGauge1.Location = new System.Drawing.Point(25, 13);
            this.solidGauge1.Name = "solidGauge1";
            this.solidGauge1.Size = new System.Drawing.Size(149, 151);
            this.solidGauge1.TabIndex = 0;
            this.solidGauge1.Text = "solidGauge1";
            // 
            // solidGauge2
            // 
            this.solidGauge2.Location = new System.Drawing.Point(220, 12);
            this.solidGauge2.Name = "solidGauge2";
            this.solidGauge2.Size = new System.Drawing.Size(149, 151);
            this.solidGauge2.TabIndex = 1;
            this.solidGauge2.Text = "solidGauge2";
            // 
            // solidGauge3
            // 
            this.solidGauge3.Location = new System.Drawing.Point(25, 170);
            this.solidGauge3.Name = "solidGauge3";
            this.solidGauge3.Size = new System.Drawing.Size(149, 151);
            this.solidGauge3.TabIndex = 2;
            this.solidGauge3.Text = "solidGauge3";
            // 
            // solidGauge4
            // 
            this.solidGauge4.Location = new System.Drawing.Point(220, 169);
            this.solidGauge4.Name = "solidGauge4";
            this.solidGauge4.Size = new System.Drawing.Size(149, 151);
            this.solidGauge4.TabIndex = 3;
            this.solidGauge4.Text = "solidGauge4";
            // 
            // solidGauge5
            // 
            this.solidGauge5.Location = new System.Drawing.Point(25, 347);
            this.solidGauge5.Name = "solidGauge5";
            this.solidGauge5.Size = new System.Drawing.Size(149, 151);
            this.solidGauge5.TabIndex = 4;
            this.solidGauge5.Text = "solidGauge5";
            // 
            // solidGauge6
            // 
            this.solidGauge6.Location = new System.Drawing.Point(220, 347);
            this.solidGauge6.Name = "solidGauge6";
            this.solidGauge6.Size = new System.Drawing.Size(149, 151);
            this.solidGauge6.TabIndex = 5;
            this.solidGauge6.Text = "solidGauge6";
            // 
            // Gauge360Example
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(732, 547);
            this.Controls.Add(this.solidGauge6);
            this.Controls.Add(this.solidGauge5);
            this.Controls.Add(this.solidGauge4);
            this.Controls.Add(this.solidGauge3);
            this.Controls.Add(this.solidGauge2);
            this.Controls.Add(this.solidGauge1);
            this.Name = "Gauge360Example";
            this.Text = "Gauge360Exampl";
            this.ResumeLayout(false);

        }

        #endregion

        private LiveCharts.WinForms.SolidGauge solidGauge1;
        private LiveCharts.WinForms.SolidGauge solidGauge2;
        private LiveCharts.WinForms.SolidGauge solidGauge3;
        private LiveCharts.WinForms.SolidGauge solidGauge4;
        private LiveCharts.WinForms.SolidGauge solidGauge5;
        private LiveCharts.WinForms.SolidGauge solidGauge6;
    }
}