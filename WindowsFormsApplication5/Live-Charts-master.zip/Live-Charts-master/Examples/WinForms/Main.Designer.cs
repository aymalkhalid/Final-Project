﻿namespace Winforms
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label29 = new System.Windows.Forms.Label();
            this.button15 = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.btnGauge = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.btnStackedArea = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.btnMultiAx = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.btnMissingPoints = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.btnLogScale = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBasicLine = new System.Windows.Forms.Button();
            this.btnIrregularIntervals = new System.Windows.Forms.Button();
            this.btnSection = new System.Windows.Forms.Button();
            this.btnZoomingAndPanning = new System.Windows.Forms.Button();
            this.btnDateTime = new System.Windows.Forms.Button();
            this.btnInvertedSeries = new System.Windows.Forms.Button();
            this.btnSeries = new System.Windows.Forms.Button();
            this.btnIObservable = new System.Windows.Forms.Button();
            this.btnLabels = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.button16 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.label30);
            this.panel1.Controls.Add(this.button16);
            this.panel1.Controls.Add(this.label29);
            this.panel1.Controls.Add(this.button15);
            this.panel1.Controls.Add(this.label28);
            this.panel1.Controls.Add(this.button14);
            this.panel1.Controls.Add(this.label27);
            this.panel1.Controls.Add(this.button13);
            this.panel1.Controls.Add(this.label26);
            this.panel1.Controls.Add(this.button12);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.button11);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.button10);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.button9);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.btnGauge);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.btnStackedArea);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.btnMultiAx);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.btnMissingPoints);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.btnLogScale);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnBasicLine);
            this.panel1.Controls.Add(this.btnIrregularIntervals);
            this.panel1.Controls.Add(this.btnSection);
            this.panel1.Controls.Add(this.btnZoomingAndPanning);
            this.panel1.Controls.Add(this.btnDateTime);
            this.panel1.Controls.Add(this.btnInvertedSeries);
            this.panel1.Controls.Add(this.btnSeries);
            this.panel1.Controls.Add(this.btnIObservable);
            this.panel1.Controls.Add(this.btnLabels);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(847, 516);
            this.panel1.TabIndex = 0;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(542, 482);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(99, 21);
            this.label29.TabIndex = 84;
            this.label29.Text = "Funnel Chart";
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(515, 426);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(160, 53);
            this.button15.TabIndex = 83;
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(377, 482);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(91, 21);
            this.label28.TabIndex = 82;
            this.label28.Text = "Gantt Chart";
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(350, 426);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(160, 53);
            this.button14.TabIndex = 81;
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(211, 482);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(73, 21);
            this.label27.TabIndex = 80;
            this.label27.Text = "Step Line";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(182, 426);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(160, 53);
            this.button13.TabIndex = 79;
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(37, 482);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(70, 21);
            this.label26.TabIndex = 78;
            this.label26.Text = "GeoMap";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(11, 426);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(160, 53);
            this.button12.TabIndex = 77;
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(715, 322);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(86, 21);
            this.label25.TabIndex = 76;
            this.label25.Text = "ScatterPlot";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(681, 264);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(160, 55);
            this.button11.TabIndex = 75;
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(372, 402);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(112, 21);
            this.label24.TabIndex = 74;
            this.label24.Text = "Angular Gauge";
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(350, 346);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(160, 53);
            this.button10.TabIndex = 73;
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(503, 322);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(188, 21);
            this.label23.TabIndex = 72;
            this.label23.Text = "Events, UiShapes, Utilities";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(515, 264);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(160, 55);
            this.button9.TabIndex = 71;
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(378, 322);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(97, 21);
            this.label22.TabIndex = 70;
            this.label22.Text = "LinqExample";
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(348, 264);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(160, 55);
            this.button8.TabIndex = 69;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(691, 402);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(121, 21);
            this.label21.TabIndex = 68;
            this.label21.Text = "Doughnut Chart";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(682, 346);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(160, 53);
            this.button7.TabIndex = 67;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(209, 402);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(85, 21);
            this.label20.TabIndex = 66;
            this.label20.Text = "360 Gauge";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(183, 346);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(160, 53);
            this.button6.TabIndex = 65;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(212, 322);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(88, 21);
            this.label19.TabIndex = 64;
            this.label19.Text = "Heat Series";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(182, 264);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(160, 55);
            this.button5.TabIndex = 63;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(40, 322);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(83, 21);
            this.label18.TabIndex = 62;
            this.label18.Text = "Pagination";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(11, 264);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(160, 55);
            this.button4.TabIndex = 61;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(691, 240);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(134, 21);
            this.label17.TabIndex = 60;
            this.label17.Text = "Dynamic Visibility";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(681, 181);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(160, 55);
            this.button3.TabIndex = 59;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(551, 402);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(73, 21);
            this.label16.TabIndex = 58;
            this.label16.Text = "Pie Chart";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(516, 346);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(160, 53);
            this.button2.TabIndex = 57;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(674, 157);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(135, 21);
            this.label15.TabIndex = 56;
            this.label15.Text = "Constant Changes";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(675, 99);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(160, 55);
            this.button1.TabIndex = 55;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(38, 402);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(85, 21);
            this.label14.TabIndex = 54;
            this.label14.Text = "180 Gauge";
            // 
            // btnGauge
            // 
            this.btnGauge.Location = new System.Drawing.Point(12, 346);
            this.btnGauge.Name = "btnGauge";
            this.btnGauge.Size = new System.Drawing.Size(160, 53);
            this.btnGauge.TabIndex = 53;
            this.btnGauge.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(691, 75);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 21);
            this.label13.TabIndex = 52;
            this.label13.Text = "Stacked Area";
            // 
            // btnStackedArea
            // 
            this.btnStackedArea.Location = new System.Drawing.Point(675, 17);
            this.btnStackedArea.Name = "btnStackedArea";
            this.btnStackedArea.Size = new System.Drawing.Size(160, 55);
            this.btnStackedArea.TabIndex = 51;
            this.btnStackedArea.UseVisualStyleBackColor = true;
            this.btnStackedArea.Click += new System.EventHandler(this.btnStackedArea_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(44, 240);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(79, 21);
            this.label12.TabIndex = 50;
            this.label12.Text = "MultiAxes";
            // 
            // btnMultiAx
            // 
            this.btnMultiAx.Location = new System.Drawing.Point(11, 181);
            this.btnMultiAx.Name = "btnMultiAx";
            this.btnMultiAx.Size = new System.Drawing.Size(160, 55);
            this.btnMultiAx.TabIndex = 49;
            this.btnMultiAx.UseVisualStyleBackColor = true;
            this.btnMultiAx.Click += new System.EventHandler(this.btnMultiAx_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(519, 157);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(112, 21);
            this.label11.TabIndex = 48;
            this.label11.Text = "Missing Points";
            // 
            // btnMissingPoints
            // 
            this.btnMissingPoints.Location = new System.Drawing.Point(508, 99);
            this.btnMissingPoints.Name = "btnMissingPoints";
            this.btnMissingPoints.Size = new System.Drawing.Size(160, 55);
            this.btnMissingPoints.TabIndex = 47;
            this.btnMissingPoints.UseVisualStyleBackColor = true;
            this.btnMissingPoints.Click += new System.EventHandler(this.btnMissingPoints_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(535, 240);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(112, 21);
            this.label10.TabIndex = 46;
            this.label10.Text = "Logrithm Scale";
            // 
            // btnLogScale
            // 
            this.btnLogScale.Location = new System.Drawing.Point(515, 181);
            this.btnLogScale.Name = "btnLogScale";
            this.btnLogScale.Size = new System.Drawing.Size(160, 55);
            this.btnLogScale.TabIndex = 45;
            this.btnLogScale.UseVisualStyleBackColor = true;
            this.btnLogScale.Click += new System.EventHandler(this.btnLogScale_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(381, 240);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 21);
            this.label9.TabIndex = 44;
            this.label9.Text = "DateTime";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(519, 75);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 21);
            this.label8.TabIndex = 43;
            this.label8.Text = "Inverted Series";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(181, 157);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(133, 21);
            this.label7.TabIndex = 42;
            this.label7.Text = "Irregular Intervals";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(327, 157);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(163, 21);
            this.label6.TabIndex = 41;
            this.label6.Text = "Zooming And Panning";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(369, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 21);
            this.label5.TabIndex = 40;
            this.label5.Text = "Basic Line";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(215, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 21);
            this.label4.TabIndex = 39;
            this.label4.Text = "Series";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(45, 157);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 21);
            this.label3.TabIndex = 38;
            this.label3.Text = "Sections";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(177, 240);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(167, 21);
            this.label2.TabIndex = 37;
            this.label2.Text = "IObservableChartPoint";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(45, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 21);
            this.label1.TabIndex = 36;
            this.label1.Text = "Labels";
            // 
            // btnBasicLine
            // 
            this.btnBasicLine.Location = new System.Drawing.Point(343, 17);
            this.btnBasicLine.Name = "btnBasicLine";
            this.btnBasicLine.Size = new System.Drawing.Size(160, 55);
            this.btnBasicLine.TabIndex = 35;
            this.btnBasicLine.UseVisualStyleBackColor = true;
            this.btnBasicLine.Click += new System.EventHandler(this.btnBasicLine_Click);
            // 
            // btnIrregularIntervals
            // 
            this.btnIrregularIntervals.Location = new System.Drawing.Point(180, 99);
            this.btnIrregularIntervals.Name = "btnIrregularIntervals";
            this.btnIrregularIntervals.Size = new System.Drawing.Size(160, 55);
            this.btnIrregularIntervals.TabIndex = 34;
            this.btnIrregularIntervals.UseVisualStyleBackColor = true;
            this.btnIrregularIntervals.Click += new System.EventHandler(this.btnIrregularIntervals_Click);
            // 
            // btnSection
            // 
            this.btnSection.Location = new System.Drawing.Point(11, 99);
            this.btnSection.Name = "btnSection";
            this.btnSection.Size = new System.Drawing.Size(160, 55);
            this.btnSection.TabIndex = 33;
            this.btnSection.UseVisualStyleBackColor = true;
            this.btnSection.Click += new System.EventHandler(this.btnSection_Click);
            // 
            // btnZoomingAndPanning
            // 
            this.btnZoomingAndPanning.Location = new System.Drawing.Point(343, 99);
            this.btnZoomingAndPanning.Name = "btnZoomingAndPanning";
            this.btnZoomingAndPanning.Size = new System.Drawing.Size(160, 55);
            this.btnZoomingAndPanning.TabIndex = 32;
            this.btnZoomingAndPanning.UseVisualStyleBackColor = true;
            this.btnZoomingAndPanning.Click += new System.EventHandler(this.btnZoomingAndPanning_Click);
            // 
            // btnDateTime
            // 
            this.btnDateTime.Location = new System.Drawing.Point(349, 181);
            this.btnDateTime.Name = "btnDateTime";
            this.btnDateTime.Size = new System.Drawing.Size(160, 55);
            this.btnDateTime.TabIndex = 31;
            this.btnDateTime.UseVisualStyleBackColor = true;
            this.btnDateTime.Click += new System.EventHandler(this.btnDateTime_Click);
            // 
            // btnInvertedSeries
            // 
            this.btnInvertedSeries.Location = new System.Drawing.Point(509, 17);
            this.btnInvertedSeries.Name = "btnInvertedSeries";
            this.btnInvertedSeries.Size = new System.Drawing.Size(160, 55);
            this.btnInvertedSeries.TabIndex = 30;
            this.btnInvertedSeries.UseVisualStyleBackColor = true;
            this.btnInvertedSeries.Click += new System.EventHandler(this.btnInvertedSeries_Click);
            // 
            // btnSeries
            // 
            this.btnSeries.Location = new System.Drawing.Point(177, 17);
            this.btnSeries.Name = "btnSeries";
            this.btnSeries.Size = new System.Drawing.Size(160, 55);
            this.btnSeries.TabIndex = 29;
            this.btnSeries.UseVisualStyleBackColor = true;
            this.btnSeries.Click += new System.EventHandler(this.btnSeries_Click);
            // 
            // btnIObservable
            // 
            this.btnIObservable.Location = new System.Drawing.Point(180, 181);
            this.btnIObservable.Name = "btnIObservable";
            this.btnIObservable.Size = new System.Drawing.Size(160, 55);
            this.btnIObservable.TabIndex = 28;
            this.btnIObservable.UseVisualStyleBackColor = true;
            this.btnIObservable.Click += new System.EventHandler(this.btnIObservable_Click);
            // 
            // btnLabels
            // 
            this.btnLabels.Location = new System.Drawing.Point(11, 17);
            this.btnLabels.Name = "btnLabels";
            this.btnLabels.Size = new System.Drawing.Size(160, 55);
            this.btnLabels.TabIndex = 27;
            this.btnLabels.UseVisualStyleBackColor = true;
            this.btnLabels.Click += new System.EventHandler(this.btnLabels_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(718, 482);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(56, 21);
            this.label30.TabIndex = 86;
            this.label30.Text = "Events";
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(681, 426);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(160, 53);
            this.button16.TabIndex = 85;
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(847, 516);
            this.Controls.Add(this.panel1);
            this.Name = "Main";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnGauge;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnStackedArea;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnMultiAx;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnMissingPoints;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnLogScale;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBasicLine;
        private System.Windows.Forms.Button btnIrregularIntervals;
        private System.Windows.Forms.Button btnSection;
        private System.Windows.Forms.Button btnZoomingAndPanning;
        private System.Windows.Forms.Button btnDateTime;
        private System.Windows.Forms.Button btnInvertedSeries;
        private System.Windows.Forms.Button btnSeries;
        private System.Windows.Forms.Button btnIObservable;
        private System.Windows.Forms.Button btnLabels;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button button16;
    }
}

